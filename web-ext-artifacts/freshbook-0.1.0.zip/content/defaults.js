/* FreshBook - shared defaults */
window.CF_DEFAULTS = {
  enabled: true,
  removeStories: true,
  removeReels: true,
  removeSuggested: true,
  removeWall: false
};
